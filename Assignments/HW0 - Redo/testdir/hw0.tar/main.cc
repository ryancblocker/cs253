#include <iostream>
using namespace std;

int main()
{
	//How many students does it take to change a lightbulb?
	cout << "Nine-one to install the bulb, and the other eight" << "\n";
	cout <<  "are needed to invent an extravagant and expensive way" << "\n";
	cout << "to power the bulb sustainably." << "\n";
	return 0;
}

